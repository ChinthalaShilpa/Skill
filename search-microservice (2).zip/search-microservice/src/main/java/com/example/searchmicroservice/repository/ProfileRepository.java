package com.example.searchmicroservice.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.searchmicroservice.profile.entity.Profile;

@Repository
public interface ProfileRepository extends MongoRepository<Profile, Long> {
    List<Profile> findByNameStartingWith(String name);
    List<Profile> findByAssociateId(String associateId);
 
    List<Profile> findByHtmlCssJsAndExpertiseGreaterThan(String skill, int expertise);
    List<Profile> findByAngularAndExpertiseGreaterThan(String skill, int expertise);
    List<Profile> findBySpringAndExpertiseGreaterThan(String skill, int expertise);
    List<Profile> findByReactAndExpertiseGreaterThan(String skill, int expertise);
    List<Profile> findByRestfulAndExpertiseGreaterThan(String skill, int expertise);
    List<Profile> findBySpokenAndExpertiseGreaterThan(String skill, int expertise);
    List<Profile> findByCommunicationAndExpertiseGreaterThan(String skill, int expertise);
 //   List<Profile> findByAptitudeAndExpertiseGreaterThan(String skill, int expertise);
    //@Query("SELECT p FROM Profile p WHERE p.aptitude = :aptitude AND p.expertise > :expertise")
    //@Query("{ 'aptitude' : ?0, 'expertise' : { $gt : ?1 } }")
   // List<Profile> findByAptitudeAndExpertiseGreaterThan(@Param("aptitude") String aptitude, @Param("expertise") int expertise);
    List<Profile> findByAptitude(String key, int value);
}