package com.example.searchmicroservice.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.searchmicroservice.profile.entity.Profile;
import com.example.searchmicroservice.service.ProfileService;

@RestController
@RequestMapping("/search")
public class SearchController {
	 @Autowired
	    private ProfileService profileService;
	 
	    @GetMapping("/profiles")
	    public ResponseEntity<List<Profile>> searchProfiles(@RequestParam(required = false) String name,
	                                                        @RequestParam(required = false) String associateId,
	                                                        @RequestParam(required = false) Map<String, Integer> skill ){
	        List<Profile> profiles;
	        //System.out.println(name);
	        if (name != null) {
	            profiles = profileService.searchProfilesByName(name);
	        } else if (associateId != null) {
	            profiles = profileService.searchProfilesByAssociateId(associateId);
	        } else if (skill != null) {
//	        	if(skill.equalsIgnoreCase("htmlCssJs")) {
//	            profiles = profileService.searchProfilesByHtmlCssJs(skill);
//	        	}
//	        	else if(skill.equalsIgnoreCase("angular")) {
//	        		profiles = profileService.searchProfilesByAngular(skill);
//	        	}
//	        	else if(skill.equalsIgnoreCase("spring")) {
//	        		profiles = profileService.searchProfilesBySpring(skill);
//	        	}
//	        	else if(skill.equalsIgnoreCase("react")) {
//	        		profiles = profileService.searchProfilesByReact(skill);
//	        	}
//	        	else if(skill.equalsIgnoreCase("restful")) {
//	        		profiles = profileService.searchProfilesByRestful(skill);
//	        	}
//	        	else if(skill.equalsIgnoreCase("spoken")) {
//	        		profiles = profileService.searchProfilesBySpoken(skill);
//	        	}
//	        	else if(skill.equalsIgnoreCase("communication")) {
//	        		profiles = profileService.searchProfilesByCommunication(skill);
//	        	}
	        	for (Map.Entry<String, Integer> entry : skill.entrySet()) {         
	        		String skill1 = entry.getKey();           
	        	//	int expertise = entry.getValue();  
	        	// Process the skill and expertise as needed        }
	        		profiles = profileService.searchProfilesByAptitude(skill1);

	        	}
	        	profiles=null;
	        } else {
	            // Handle invalid request
	            return ResponseEntity.badRequest().build();
	        }
	        return ResponseEntity.ok(profiles);
	    }
}
