package com.example.searchmicroservice.profile.entity;

import java.util.Date;
import java.util.Map;

import javax.annotation.Generated;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document

public class Profile {
 
    @NotBlank
    @Size(min = 5, max = 30)
    private String name;
 
    @NotBlank
    @Size(min = 5, max = 30)
    @Pattern(regexp = "^CTS.*", message = "Associate ID must start with 'CTS'")
    private String associateId;
 
    @NotBlank
    @Email
    private String email;
 
    @NotBlank
    @Size(min = 10, max = 10)
    @Pattern(regexp = "\\d{10}", message = "Mobile number must be 10 digits")
    private String mobile;
 
    //@Enumerated(EnumType.STRING)
    @Min(value = 0, message = "Expertise level must be between 0 and 20")
    @Max(value = 20, message = "Expertise level must be between 0 and 20")
    private int htmlCssJs;
 
    @Min(value = 0, message = "Expertise level must be between 0 and 20")
    @Max(value = 20, message = "Expertise level must be between 0 and 20")
    private int angular;
    
    @Min(value = 0, message = "Expertise level must be between 0 and 20")
    @Max(value = 20, message = "Expertise level must be between 0 and 20")
    private int react;
    
    @Min(value = 0, message = "Expertise level must be between 0 and 20")
    @Max(value = 20, message = "Expertise level must be between 0 and 20")
    private int spring;
    
    @Min(value = 0, message = "Expertise level must be between 0 and 20")
    @Max(value = 20, message = "Expertise level must be between 0 and 20")
    private int restful;
    
    //@Enumerated(EnumType.STRING)
    @Min(value = 0, message = "Expertise level must be between 0 and 20")
    @Max(value = 20, message = "Expertise level must be between 0 and 20")
    private int spoken;
    
    @Min(value = 0, message = "Expertise level must be between 0 and 20")
    @Max(value = 20, message = "Expertise level must be between 0 and 20")
    private int communication;
    
    @Min(value = 0, message = "Expertise level must be between 0 and 20")
    @Max(value = 20, message = "Expertise level must be between 0 and 20")
    private Map<String,Integer> aptitude;
 
    public int getSpoken() {
		return spoken;
	}

	public void setSpoken(int spoken) {
		this.spoken = spoken;
	}

	public int getCommunication() {
		return communication;
	}

	public void setCommunication(int communication) {
		this.communication = communication;
	}

	

	public Map<String, Integer> getAptitude() {
		return aptitude;
	}

	public void setAptitude(Map<String, Integer> aptitude) {
		this.aptitude = aptitude;
	}



	private String userId;
 
    //@Temporal(TemporalType.TIMESTAMP)
    private Date dateAdded;
 
    private int expertise;
	

	public int getExpertise() {
		return expertise;
	}

	public void setExpertise(int expertise) {
		this.expertise = expertise;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAssociateId() {
		return associateId;
	}

	public void setAssociateId(String associateId) {
		this.associateId = associateId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	
	public int getHtmlCssJs() {
		return htmlCssJs;
	}

	public void setHtmlCssJs(int htmlCssJs) {
		this.htmlCssJs = htmlCssJs;
	}

	public int getAngular() {
		return angular;
	}

	public void setAngular(int angular) {
		this.angular = angular;
	}

	public int getReact() {
		return react;
	}

	public void setReact(int react) {
		this.react = react;
	}

	public int getSpring() {
		return spring;
	}

	public void setSpring(int spring) {
		this.spring = spring;
	}

	public int getRestful() {
		return restful;
	}

	public void setRestful(int restful) {
		this.restful = restful;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getDateAdded() {
		return dateAdded;
	}

	public void setDateAdded(Date dateAdded) {
		this.dateAdded = dateAdded;
	}

	
	
 
    // Constructors, getters, setters, etc.
}