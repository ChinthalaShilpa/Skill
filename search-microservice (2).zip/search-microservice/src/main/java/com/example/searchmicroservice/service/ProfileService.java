package com.example.searchmicroservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.searchmicroservice.profile.entity.Profile;
import com.example.searchmicroservice.repository.ProfileRepository;

@Service
public class ProfileService {
	 @Autowired
	    private ProfileRepository profileRepository;
	 
	    public List<Profile> searchProfilesByName(String name) {
	        // Implement search logic by name
	        return profileRepository.findByNameStartingWith(name);
	    }
	 
	    public List<Profile> searchProfilesByAssociateId(String associateId) {
	        // Implement search logic by associateId
	        return profileRepository.findByAssociateId(associateId);
	    }
	 
	    public List<Profile> searchProfilesByHtmlCssJs(String skill) {
	        // Implement search logic by skill with expertise level greater than 10
	        return profileRepository.findByHtmlCssJsAndExpertiseGreaterThan(skill, 10);
	    }
	    
	    public List<Profile> searchProfilesByAngular(String skill) {
	        // Implement search logic by skill with expertise level greater than 10
	        return profileRepository.findByAngularAndExpertiseGreaterThan(skill, 10);
	    }
	    
	    public List<Profile> searchProfilesBySpring(String skill) {
	        // Implement search logic by skill with expertise level greater than 10
	        return profileRepository.findBySpringAndExpertiseGreaterThan(skill, 10);
	    }
	    
	    public List<Profile> searchProfilesByReact(String skill) {
	        // Implement search logic by skill with expertise level greater than 10
	        return profileRepository.findByReactAndExpertiseGreaterThan(skill, 10);
	    }
	    
	    public List<Profile> searchProfilesByRestful(String skill) {
	        // Implement search logic by skill with expertise level greater than 10
	        return profileRepository.findByRestfulAndExpertiseGreaterThan(skill, 10);
	    }
	    
	    public List<Profile> searchProfilesBySpoken(String skill) {
	        // Implement search logic by skill with expertise level greater than 10
	    	System.out.println(profileRepository.findBySpokenAndExpertiseGreaterThan(skill, 10));
	        return profileRepository.findBySpokenAndExpertiseGreaterThan(skill, 10);
	    }
	    
	    public List<Profile> searchProfilesByCommunication(String skill) {
	        // Implement search logic by skill with expertise level greater than 10
	        return profileRepository.findByCommunicationAndExpertiseGreaterThan(skill, 10);
	    }
	    
	    public List<Profile> searchProfilesByAptitude(String skill) {
	        // Implement search logic by skill with expertise level greater than 10
	        return profileRepository.findByAptitude(skill, 14);
	    }
}
