package com.example.skilltracker.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.skilltracker.exception.UpdateBeforeException;
import com.example.skilltracker.exception.UserNotFoundException;
import com.example.skilltracker.profile.entity.Profile;
import com.example.skilltracker.service.ProfileService;

@RestController
@RequestMapping("/maintain")
public class MaintainController {
	@Autowired
    private ProfileService profileService;
 
    @PostMapping("/profile")
    public ResponseEntity<Profile> addProfile(@RequestBody @Valid Profile profile) {
        Profile newProfile = profileService.addProfile(profile);
        return ResponseEntity.ok(newProfile);
    }
 
    @PutMapping("/profile/{userId}")
    public ResponseEntity<Profile> updateProfile(@PathVariable  String userId, @RequestBody @Valid Profile profile) throws UpdateBeforeException, UserNotFoundException {
        Profile updatedProfile = profileService.updateProfile(userId, profile);
        return ResponseEntity.ok(updatedProfile);
    }
}
