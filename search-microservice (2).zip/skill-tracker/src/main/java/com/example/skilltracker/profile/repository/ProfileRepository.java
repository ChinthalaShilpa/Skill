package com.example.skilltracker.profile.repository;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.skilltracker.profile.entity.Profile;

public interface ProfileRepository extends MongoRepository<Profile, String> {

}
