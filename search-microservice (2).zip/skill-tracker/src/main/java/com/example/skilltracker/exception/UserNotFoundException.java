package com.example.skilltracker.exception;

public class UserNotFoundException extends Exception {
	 public UserNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
	
		   super(msg);
	   }
}
