package com.example.skilltracker.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.skilltracker.exception.UpdateBeforeException;
import com.example.skilltracker.exception.UserNotFoundException;
import com.example.skilltracker.profile.entity.Profile;
import com.example.skilltracker.profile.repository.ProfileRepository;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
@Service
public class ProfileService {
	@Autowired
    private ProfileRepository profileRepository;
 
    public Profile addProfile(Profile profile) {
        // Validate profile fields and add to repository
    	//SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    	//profile.setDateAdded(formatter.format(new Date()));
    	profile.setDateAdded(LocalDate.now());
        return profileRepository.save(profile);
    }
 
    public Profile updateProfile(String userId, Profile profile) throws UpdateBeforeException, UserNotFoundException {
        // Validate userId and profile fields, then update in repository
        Profile existingProfile = profileRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("Profile not found with id: " + userId));
        if(LocalDate.now().minusDays(10).isAfter(existingProfile.getDateAdded())) {
        	// Update fields that can be updated
            existingProfile.setHtmlCssJs(profile.getHtmlCssJs());
            existingProfile.setReact(profile.getReact());
            existingProfile.setAngular(profile.getAngular());
            existingProfile.setRestful(profile.getRestful());
            existingProfile.setSpring(profile.getSpring());
            existingProfile.setSpoken(profile.getSpoken());
            existingProfile.setCommunication(profile.getCommunication());
            existingProfile.setAptitude(profile.getAptitude());
            existingProfile.setDateAdded(LocalDate.now());
            // Update other fields as needed
            return profileRepository.save(existingProfile);
        }
        else {
        	throw new UpdateBeforeException("cannot update");
        }
        	
       
        
        
        
    }
}
