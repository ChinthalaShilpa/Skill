package com.example.skilltracker.exception;

public class UpdateBeforeException extends Exception {
   public UpdateBeforeException(String msg) {
	   super(msg);
   }
}
